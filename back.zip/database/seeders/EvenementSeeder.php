<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Evenement;
use Illuminate\Support\Facades\Storage;

class EvenementSeeder extends Seeder
{
    public function run(): void
    {
        // Events seeder - add your data via the API forms
    }
}
