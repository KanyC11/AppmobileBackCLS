<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Podcast;
use Illuminate\Support\Facades\Storage;

class PodcastSeeder extends Seeder
{
    public function run(): void
    {
        // Podcasts seeder - add your data via the API forms
    }
}
