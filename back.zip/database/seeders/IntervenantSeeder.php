<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Intervenant;

class IntervenantSeeder extends Seeder
{
    public function run(): void
    {
        // Intervenants seeder - add your data via the API forms
    }
}
