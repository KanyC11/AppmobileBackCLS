<?php

use Illuminate\Support\Facades\Route;

// Routes can be added here as needed
